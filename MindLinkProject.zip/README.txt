Two search modes are available by passing a flag as arguments - search by string and search by date.

To search by string, typpe the file location followed by "-s" followed by string(s) you wish to search for, e.g. 

java -jar Test.jar Interview\ Resources/chat.txt -s "ye head"

To search by date, do as above but with a "-d" and two date strings, e.g. 

java -jar Test.jar Interview\ Resources/chat.txt -d "2015/11/25 17:01:49" "2015/11/25 17:01:56"

Example test cases have been provided but are far from comprehensive.


